<form action="/" method="post">
<div class="content">
<div>
    <div class="input-wrapper">
        <label for="description">Descrição de atividades passadas e o sucesso obtido:</label>
        <textarea name="description" cols="40" rows="10"></textarea>
    </div>

    <div class="input-wrapper">
        <label for="plan">Plano de ação para a próxima quinzena:</label>
        <textarea name="plan" cols="40" rows="10"></textarea>
    </div>

    <div class="input-wrapper">
        <label for="obs">Observação:</label>
        <textarea name="obs" cols="40" rows="10"></textarea>
    </div>

    <button>Enviar</button>
</div>
</div>
</form>